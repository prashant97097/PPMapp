package com.dnvgl.ppm.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {UserModel.class, ProjectInfoModel.class, MetMastInfoModel.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {


    private static AppDatabase INSTANCE;

    public static AppDatabase getDatabase(Context context) {

        if(INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "dnvgl_db" ).build();
        }

        return INSTANCE;
    }

    public abstract UserDao userDao();
    public abstract ProjectInfoDao projectInfoDao();
    public abstract MetMastInfoDao metMastInfoDao();
}
