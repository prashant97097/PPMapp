package com.dnvgl.ppm.database;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class MetMastInfoModel {

    @PrimaryKey
    @NonNull
    private String projectNumber;

    @ColumnInfo
    private String turbineId;

    @ColumnInfo
    private String mastName;

    @ColumnInfo
    private String mastType;

    @ColumnInfo
    private String mastHeight;

    @ColumnInfo
    private String mastDimensionType1; /* length*width format */


    @ColumnInfo
    private String mastDimensionType2;


    @ColumnInfo
    private String mastDimensionType3;


    @ColumnInfo
    private String mastDimensionType4;

    @ColumnInfo
    private int noOfSegmentType1;


    @ColumnInfo
    private int noOfSegmentType2;


    @ColumnInfo
    private int noOfSegmentType3;


    @ColumnInfo
    private int noOfSegmentType4;

    @ColumnInfo
    private int lengthOfSegmentType1;

    @ColumnInfo
    private int lengthOfSegmentType2;

    @ColumnInfo
    private int lengthOfSegmentType3;

    @ColumnInfo
    private int lengthOfSegmentType4;

    @ColumnInfo
    private String primaryAnemometerMounting;

    @ColumnInfo
    private String mastCoordinateX1; /*  Format X1/X2/X3/X4..... */

    @ColumnInfo
    private String mastCoordinateX2;


    @ColumnInfo
    private String mastCoordinateX3;


    @ColumnInfo
    private String mastCoordinateX4;


    @ColumnInfo
    private String mastCoordinateX5;

    @ColumnInfo
    private String mastCoordinateY; /*  Format Y1/Y2/Y3/Y4..... */

    @ColumnInfo
    private String mastCoordinateY2;


    @ColumnInfo
    private String mastCoordinateY3;


    @ColumnInfo
    private String mastCoordinateY4;

    @ColumnInfo
    private String mastCoordinateY5;


    @NonNull
    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(@NonNull String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public String getTurbineId() {
        return turbineId;
    }

    public void setTurbineId(String turbineId) {
        this.turbineId = turbineId;
    }

    public String getMastName() {
        return mastName;
    }

    public void setMastName(String mastName) {
        this.mastName = mastName;
    }

    public String getMastType() {
        return mastType;
    }

    public void setMastType(String mastType) {
        this.mastType = mastType;
    }

    public String getMastHeight() {
        return mastHeight;
    }

    public void setMastHeight(String mastHeight) {
        this.mastHeight = mastHeight;
    }

    public String getMastDimensionType1() {
        return mastDimensionType1;
    }

    public void setMastDimensionType1(String mastDimensionType1) {
        this.mastDimensionType1 = mastDimensionType1;
    }

    public String getMastDimensionType2() {
        return mastDimensionType2;
    }

    public void setMastDimensionType2(String mastDimensionType2) {
        this.mastDimensionType2 = mastDimensionType2;
    }

    public String getMastDimensionType3() {
        return mastDimensionType3;
    }

    public void setMastDimensionType3(String mastDimensionType3) {
        this.mastDimensionType3 = mastDimensionType3;
    }

    public String getMastDimensionType4() {
        return mastDimensionType4;
    }

    public void setMastDimensionType4(String mastDimensionType4) {
        this.mastDimensionType4 = mastDimensionType4;
    }

    public int getNoOfSegmentType1() {
        return noOfSegmentType1;
    }

    public void setNoOfSegmentType1(int noOfSegmentType1) {
        this.noOfSegmentType1 = noOfSegmentType1;
    }

    public int getNoOfSegmentType2() {
        return noOfSegmentType2;
    }

    public void setNoOfSegmentType2(int noOfSegmentType2) {
        this.noOfSegmentType2 = noOfSegmentType2;
    }

    public int getNoOfSegmentType3() {
        return noOfSegmentType3;
    }

    public void setNoOfSegmentType3(int noOfSegmentType3) {
        this.noOfSegmentType3 = noOfSegmentType3;
    }

    public int getNoOfSegmentType4() {
        return noOfSegmentType4;
    }

    public void setNoOfSegmentType4(int noOfSegmentType4) {
        this.noOfSegmentType4 = noOfSegmentType4;
    }

    public int getLengthOfSegmentType1() {
        return lengthOfSegmentType1;
    }

    public void setLengthOfSegmentType1(int lengthOfSegmentType1) {
        this.lengthOfSegmentType1 = lengthOfSegmentType1;
    }

    public int getLengthOfSegmentType2() {
        return lengthOfSegmentType2;
    }

    public void setLengthOfSegmentType2(int lengthOfSegmentType2) {
        this.lengthOfSegmentType2 = lengthOfSegmentType2;
    }

    public int getLengthOfSegmentType3() {
        return lengthOfSegmentType3;
    }

    public void setLengthOfSegmentType3(int lengthOfSegmentType3) {
        this.lengthOfSegmentType3 = lengthOfSegmentType3;
    }

    public int getLengthOfSegmentType4() {
        return lengthOfSegmentType4;
    }

    public void setLengthOfSegmentType4(int lengthOfSegmentType4) {
        this.lengthOfSegmentType4 = lengthOfSegmentType4;
    }

    public String getPrimaryAnemometerMounting() {
        return primaryAnemometerMounting;
    }

    public void setPrimaryAnemometerMounting(String primaryAnemometerMounting) {
        this.primaryAnemometerMounting = primaryAnemometerMounting;
    }

    public String getMastCoordinateX1() {
        return mastCoordinateX1;
    }

    public void setMastCoordinateX1(String mastCoordinateX1) {
        this.mastCoordinateX1 = mastCoordinateX1;
    }

    public String getMastCoordinateX2() {
        return mastCoordinateX2;
    }

    public void setMastCoordinateX2(String mastCoordinateX2) {
        this.mastCoordinateX2 = mastCoordinateX2;
    }

    public String getMastCoordinateX3() {
        return mastCoordinateX3;
    }

    public void setMastCoordinateX3(String mastCoordinateX3) {
        this.mastCoordinateX3 = mastCoordinateX3;
    }

    public String getMastCoordinateX4() {
        return mastCoordinateX4;
    }

    public void setMastCoordinateX4(String mastCoordinateX4) {
        this.mastCoordinateX4 = mastCoordinateX4;
    }

    public String getMastCoordinateX5() {
        return mastCoordinateX5;
    }

    public void setMastCoordinateX5(String mastCoordinateX5) {
        this.mastCoordinateX5 = mastCoordinateX5;
    }

    public String getMastCoordinateY() {
        return mastCoordinateY;
    }

    public void setMastCoordinateY(String mastCoordinateY) {
        this.mastCoordinateY = mastCoordinateY;
    }

    public String getMastCoordinateY2() {
        return mastCoordinateY2;
    }

    public void setMastCoordinateY2(String mastCoordinateY2) {
        this.mastCoordinateY2 = mastCoordinateY2;
    }

    public String getMastCoordinateY3() {
        return mastCoordinateY3;
    }

    public void setMastCoordinateY3(String mastCoordinateY3) {
        this.mastCoordinateY3 = mastCoordinateY3;
    }

    public String getMastCoordinateY4() {
        return mastCoordinateY4;
    }

    public void setMastCoordinateY4(String mastCoordinateY4) {
        this.mastCoordinateY4 = mastCoordinateY4;
    }

    public String getMastCoordinateY5() {
        return mastCoordinateY5;
    }

    public void setMastCoordinateY5(String mastCoordinateY5) {
        this.mastCoordinateY5 = mastCoordinateY5;
    }




}
