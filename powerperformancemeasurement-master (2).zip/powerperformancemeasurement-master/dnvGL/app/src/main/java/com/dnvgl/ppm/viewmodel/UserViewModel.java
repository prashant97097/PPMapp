package com.dnvgl.ppm.viewmodel;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.lifecycle.AndroidViewModel;

import com.dnvgl.ppm.MainActivity;
import com.dnvgl.ppm.database.AppDatabase;
import com.dnvgl.ppm.database.UserModel;

public class UserViewModel extends AndroidViewModel {

   // private final LiveData<UserModel> userModelLiveData;
   private static final String TAG = "UserViewModel";
    private AppDatabase appDatabase;
    Context mContext;

    public UserViewModel(Application application) {
        super(application);
        mContext = this.getApplication();
        appDatabase = AppDatabase.getDatabase(mContext);
    }


    public UserModel getPasswordByUserName(UserModel username) {
        //put this into AsynTask
          new finduserByNameAsyncTask().execute(username);

          return null;
    }

    public void insertAUSer(UserModel user) {
        new insertUserAsyncTask().execute(user);
    }

    private class insertUserAsyncTask extends AsyncTask<UserModel, Void, Void> {
        @Override
        protected Void doInBackground(final UserModel... user) {
            appDatabase.userDao().insertAUser(user[0]);
            return null;
        }
    }

    //
    private  class finduserByNameAsyncTask extends AsyncTask<UserModel, Void, UserModel> {


        ProgressBar progressBar = new ProgressBar(mContext);
        UserModel userModelFromUI = new UserModel();

        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
        }
        @Override
        protected UserModel doInBackground(final UserModel... username) {
            userModelFromUI.userName = username[0].userName;
            userModelFromUI.password = username[0].password;

            return  appDatabase.userDao().findByUserName(username[0].userName);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(UserModel result) {

            progressBar.setVisibility(View.GONE);
            if(checkPassword(result)) {
                Intent mainIntent = new Intent(mContext, MainActivity.class);
                mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                Bundle bundle = new Bundle();
                bundle.putString("UserName", userModelFromUI.userName.toString());
                mainIntent.putExtras(bundle);
                mContext.startActivity(mainIntent);
            } else {
                Toast.makeText(mContext, "Wrong userName or Password", Toast.LENGTH_LONG).show();
            }
        }

        private boolean checkPassword(UserModel result) {

            Log.i(TAG, userModelFromUI.password);
            Log.i(TAG, result.password);

            if(userModelFromUI.password.equalsIgnoreCase(result.password)) {
                return true;
            }

            return false;
        }
    }

}
