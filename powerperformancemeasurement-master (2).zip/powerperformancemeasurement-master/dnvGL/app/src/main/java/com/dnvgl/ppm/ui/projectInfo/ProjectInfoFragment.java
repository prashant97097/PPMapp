package com.dnvgl.ppm.ui.projectInfo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.dnvgl.ppm.R;
import com.dnvgl.ppm.database.ProjectInfoModel;
import com.dnvgl.ppm.viewmodel.ProjectInfoViewModel;

public class ProjectInfoFragment extends Fragment {

    private ProjectInfoViewModel projectInfoViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        projectInfoViewModel =
                ViewModelProviders.of(this).get(ProjectInfoViewModel.class);
        View root = inflater.inflate(R.layout.fragment_projectinfo, container, false);

        final EditText textView = root.findViewById(R.id.projectNumber);
        final EditText textView1 = root.findViewById(R.id.projectEng);
        final EditText textView2 = root.findViewById(R.id.supportEng);
        final EditText textView3 = root.findViewById(R.id.customer);
        final EditText textView4 = root.findViewById(R.id.turbineId);
        final EditText textView5 = root.findViewById(R.id.siteName);
        final EditText textView6 = root.findViewById(R.id.turbineMake);
       /* final EditText textView7 = root.findViewById(R.id.turbineType);
        final EditText textView8 = root.findViewById(R.id.ratedCapacity);
        final EditText textView9 = root.findViewById(R.id.hubHeight);
        final EditText textView10 = root.findViewById(R.id.rotorDia);
        final EditText textView11 = root.findViewById(R.id.custContName);
        final EditText textView12 = root.findViewById(R.id.custMobleNumber);
        final EditText textView13 = root.findViewById(R.id.date);*/



        final Button submitBtn = root.findViewById(R.id.submit);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProjectInfoModel projectInfoModel = new ProjectInfoModel();
                projectInfoModel.setProjectNumber(textView.getText().toString());
                projectInfoModel.setProjectEng(textView1.getText().toString());
                projectInfoViewModel.insertAProjectInfo(projectInfoModel);
            }
        });

        final Button editBtn = root.findViewById(R.id.edit);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 projectInfoViewModel.getProjectInfoByProjectNumber("1234");
            }
        });

        projectInfoViewModel.getProjectInfoText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView6.setText(s);
            }
        });
        return root;
    }
}