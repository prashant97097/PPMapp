package com.dnvgl.ppm.ui.send;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.dnvgl.ppm.R;

import java.io.File;

public class SendFragment extends Fragment {

    private SendViewModel sendViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        sendViewModel =
                ViewModelProviders.of(this).get(SendViewModel.class);
        View root = inflater.inflate(R.layout.fragment_send, container, false);
        final TextView textView = root.findViewById(R.id.text_send);

        sendViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }

   public void onActivityCreated(Bundle savedInstanceState) {
       super.onActivityCreated(savedInstanceState);
       File filePath = new File(Environment.getExternalStorageDirectory() + "/" + File.separator + "test2.pdf");
       //Uri path = Uri.fromFile(filePath );

       if(filePath.exists()) {
           Toast.makeText(getActivity(), "Done :"+ filePath.getAbsolutePath(), Toast.LENGTH_LONG).show();
Log.i("AMIT", "Done :"+ filePath.getAbsolutePath());

           Uri contentUri = FileProvider.getUriForFile(getContext(), "com.dnvgl.ppm.fileprovider", filePath);

           Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
           pdfIntent.setDataAndType(contentUri , "application/pdf");
           pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
           try
           {
               startActivity(pdfIntent ); }
           catch (ActivityNotFoundException e)
           {
               Toast.makeText(getActivity(),"No Application available to viewPDF",
                       Toast.LENGTH_SHORT).show();
           }

   }
   }
}