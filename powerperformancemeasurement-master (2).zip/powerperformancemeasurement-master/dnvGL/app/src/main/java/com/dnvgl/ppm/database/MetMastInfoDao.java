package com.dnvgl.ppm.database;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MetMastInfoDao {

    @Query("SELECT * FROM MetMastInfoModel")
    List<MetMastInfoModel> getAllMetMastInfo();

    @Query("SELECT * FROM MetMastInfoModel WHERE projectNumber = :projectNumber")
    MetMastInfoModel loadMetMastByProjectNumber(String projectNumber);

    @Query("SELECT * FROM MetMastInfoModel WHERE turbineId = :turbineId")
    MetMastInfoModel findMetMastByTurbineId(String turbineId);

    @Insert
    void insertAllMetMastInfo(MetMastInfoModel... metMastInfoModels);

    @Insert
    void insertAMetMastInfo(MetMastInfoModel metMastInfoModel);

    @Delete
    void delete(MetMastInfoModel metMastInfoModel);
}
