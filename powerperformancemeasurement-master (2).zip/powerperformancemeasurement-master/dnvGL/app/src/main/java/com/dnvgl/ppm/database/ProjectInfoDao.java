package com.dnvgl.ppm.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
@Dao
public interface ProjectInfoDao {

    @Query("SELECT * FROM ProjectInfoModel")
    List<ProjectInfoModel> getAllProjectInfo();

    @Query("SELECT * FROM ProjectInfoModel WHERE projectNumber = :projectNumber")
    ProjectInfoModel loadByProjectNumber(String projectNumber);

    @Query("SELECT * FROM ProjectInfoModel WHERE turbineId = :turbineId")
    ProjectInfoModel findByTurbineId(String turbineId);

    @Insert
    void insertAllProjectInfo(ProjectInfoModel... projectInfos);

    @Insert
    void insertAProjectInfo(ProjectInfoModel projectInfo);

    @Delete
    void delete(ProjectInfoModel projectInfo);
}
