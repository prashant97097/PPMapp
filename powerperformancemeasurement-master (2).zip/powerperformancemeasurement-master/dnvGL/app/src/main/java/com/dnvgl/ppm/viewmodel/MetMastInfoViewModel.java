package com.dnvgl.ppm.viewmodel;

import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.dnvgl.ppm.database.AppDatabase;
import com.dnvgl.ppm.database.MetMastInfoModel;
import com.dnvgl.ppm.database.ProjectInfoModel;

public class MetMastInfoViewModel extends AndroidViewModel {


    Context mContext;
    MutableLiveData<String> mMastName;

    public MetMastInfoViewModel(@NonNull Application application) {
        super(application);

        mContext = application;
        mMastName = new MutableLiveData<>();
        mMastName.setValue("");
    }


    public void getMetMastInfoByProjectNumber(String  projectNumber) {
        //put this into AsynTask
        new MetMastInfoViewModel.findMetMastInfoByProjectNumberAsyncTask().execute(projectNumber);


    }

    private class findMetMastInfoByProjectNumberAsyncTask extends AsyncTask<String, Void, MetMastInfoModel> {
        @Override
        protected MetMastInfoModel doInBackground(final String... projectNumber) {
            return AppDatabase.getDatabase(mContext).metMastInfoDao().loadMetMastByProjectNumber(projectNumber[0]);
            //return null;
        }

        @Override
        protected void onPostExecute(MetMastInfoModel result){
            Log.i("MetmastInfoViewModel", result.getMastName());
            mMastName.setValue(result.getMastName());

        }
    }

    public void getMetMastInfoByturbineId(String  turbineId) {
        //put this into AsynTask
        new MetMastInfoViewModel.findMetMastInfoByturbineIdAsyncTask().execute(turbineId);


    }

    private class findMetMastInfoByturbineIdAsyncTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(final String... turbineId) {
            AppDatabase.getDatabase(mContext).metMastInfoDao().findMetMastByTurbineId(turbineId[0]);
            return null;
        }
    }


    public void insertAMetMastInfo(MetMastInfoModel projectInfo) {
        new MetMastInfoViewModel.insertMetMastInfoAsyncTask().execute(projectInfo);
    }

    private class insertMetMastInfoAsyncTask extends AsyncTask<MetMastInfoModel, Void, Void> {
        @Override
        protected Void doInBackground(final MetMastInfoModel... metMastInfo) {
            AppDatabase.getDatabase(mContext).metMastInfoDao().insertAMetMastInfo(metMastInfo[0]);
            return null;
        }
    }

    public LiveData<String> getMetMastInfoText() {
        return mMastName;
    }
}
