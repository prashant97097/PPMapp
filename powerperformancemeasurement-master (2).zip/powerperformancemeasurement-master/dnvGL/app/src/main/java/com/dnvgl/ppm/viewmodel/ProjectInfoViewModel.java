package com.dnvgl.ppm.viewmodel;

import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.dnvgl.ppm.database.AppDatabase;
import com.dnvgl.ppm.database.ProjectInfoModel;


public class ProjectInfoViewModel extends AndroidViewModel {

    private Context mContext;
     private MutableLiveData<String>  mEngineerName;

    public ProjectInfoViewModel(@NonNull Application application) {
        super(application);
        mContext = this.getApplication();
        mEngineerName = new MutableLiveData<>();
        mEngineerName.setValue("");
    }


    public void getProjectInfoByProjectNumber(String  projectNumber) {
        //put this into AsynTask
        new ProjectInfoViewModel.findProjectInfoByProjectNumberAsyncTask().execute(projectNumber);


    }

    private class findProjectInfoByProjectNumberAsyncTask extends AsyncTask<String, Void, ProjectInfoModel> {
        @Override
        protected ProjectInfoModel doInBackground(final String... projectNumber) {
            return AppDatabase.getDatabase(mContext).projectInfoDao().loadByProjectNumber(projectNumber[0]);
            //return null;
        }

        @Override
        protected void onPostExecute(ProjectInfoModel result){
            Log.i("ProjectInfoViewModel", result.getProjectEng());
            mEngineerName.setValue(result.getProjectEng());

        }
    }

        public void getProjectInfoByturbineId(String  turbineId) {
            //put this into AsynTask
            new ProjectInfoViewModel.findProjectInfoByturbineIdAsyncTask().execute(turbineId);


        }

        private class findProjectInfoByturbineIdAsyncTask extends AsyncTask<String, Void, Void> {
            @Override
            protected Void doInBackground(final String... turbineId) {
                AppDatabase.getDatabase(mContext).projectInfoDao().findByTurbineId(turbineId[0]);
                return null;
            }
    }


    public void insertAProjectInfo(ProjectInfoModel projectInfo) {
        new ProjectInfoViewModel.insertProjectInfoAsyncTask().execute(projectInfo);
    }

    private class insertProjectInfoAsyncTask extends AsyncTask<ProjectInfoModel, Void, Void> {
        @Override
        protected Void doInBackground(final ProjectInfoModel... projectInfo) {
            AppDatabase.getDatabase(mContext).projectInfoDao().insertAProjectInfo(projectInfo[0]);
            return null;
        }
    }

    public LiveData<String> getProjectInfoText() {
        return mEngineerName;
    }
}
