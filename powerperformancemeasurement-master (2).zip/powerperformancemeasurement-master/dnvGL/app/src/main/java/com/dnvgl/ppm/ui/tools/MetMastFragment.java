package com.dnvgl.ppm.ui.tools;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.dnvgl.ppm.R;
import com.dnvgl.ppm.database.MetMastInfoModel;
import com.dnvgl.ppm.database.ProjectInfoModel;
import com.dnvgl.ppm.viewmodel.MetMastInfoViewModel;

public class MetMastFragment extends Fragment {

    private MetMastInfoViewModel metMastInfoViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        metMastInfoViewModel =
                ViewModelProviders.of(this).get(MetMastInfoViewModel.class);
        View root = inflater.inflate(R.layout.fragment_tools, container, false);


        final EditText textView = root.findViewById(R.id.projectNumber);
        final EditText textView1 = root.findViewById(R.id.turbineId);
        final EditText textView2 = root.findViewById(R.id.mastName);
        final EditText textView3 = root.findViewById(R.id.mastType);
        final EditText textView4 = root.findViewById(R.id.mastHeight);
        final EditText textView5 = root.findViewById(R.id.mastDimensionType1);
        final EditText textView6 = root.findViewById(R.id.mastDimensionType2);
       /* final EditText textView7 = root.findViewById(R.id.turbineType);
        final EditText textView8 = root.findViewById(R.id.ratedCapacity);
        final EditText textView9 = root.findViewById(R.id.hubHeight);
        final EditText textView10 = root.findViewById(R.id.rotorDia);
        final EditText textView11 = root.findViewById(R.id.custContName);
        final EditText textView12 = root.findViewById(R.id.custMobleNumber);
        final EditText textView13 = root.findViewById(R.id.date);*/



        final Button submitBtn = root.findViewById(R.id.submit);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MetMastInfoModel metMastInfoModel = new MetMastInfoModel();
                metMastInfoModel.setProjectNumber(textView.getText().toString());
                metMastInfoModel.setTurbineId(textView1.getText().toString());
                metMastInfoModel.setMastName(textView2.getText().toString());
                metMastInfoViewModel.insertAMetMastInfo(metMastInfoModel);
                Toast.makeText(getActivity(), "Saved Successfully", Toast.LENGTH_LONG).show();
            }
        });

        final Button editBtn = root.findViewById(R.id.edit);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                metMastInfoViewModel.getMetMastInfoByProjectNumber("12345");
            }
        });


        //final TextView textView = root.findViewById(R.id.text_tools);
        metMastInfoViewModel.getMetMastInfoText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView6.setText(s);
            }
        });
        return root;
    }
}