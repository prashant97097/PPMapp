package com.dnvgl.ppm.database;


import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {

    @Query("SELECT * FROM UserModel")
    List<UserModel> getAll();

    @Query("SELECT * FROM UserModel WHERE uid = :userIds")
    List<UserModel> loadAllByIds(int userIds);

    @Query("SELECT * FROM UserModel WHERE user_name = :userName")
    UserModel findByUserName(String userName);

    @Insert
    void insertAll(UserModel... users);

    @Insert
    void insertAUser(UserModel user);

    @Delete
    void delete(UserModel user);

}
