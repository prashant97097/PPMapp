package com.dnvgl.ppm.database;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class ProjectInfoModel {

    @PrimaryKey
    @NonNull
    private String projectNumber;

    @ColumnInfo
    private String projectEng;

    @ColumnInfo
    private String supportEng;

    @ColumnInfo
    private String customer;

    @ColumnInfo
    private String turbineId;

    @ColumnInfo
    private String siteName;

    @ColumnInfo
    private String turbineMake;

    @ColumnInfo
    private String turbineType;

    @ColumnInfo
    private int ratedCapacity;

    @ColumnInfo
    private int hubHeight;

    @ColumnInfo
    private int rotorDia;

    @ColumnInfo
    private String customerContactName;

    @ColumnInfo
    private String customeContactMobileNumber;

    @ColumnInfo
    private String date;

    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public String getProjectEng() {
        return projectEng;
    }

    public void setProjectEng(String projectEng) {
        this.projectEng = projectEng;
    }

    public String getSupportEng() {
        return supportEng;
    }

    public void setSupportEng(String supportEng) {
        this.supportEng = supportEng;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getTurbineId() {
        return turbineId;
    }

    public void setTurbineId(String turbineId) {
        this.turbineId = turbineId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getTurbineMake() {
        return turbineMake;
    }

    public void setTurbineMake(String turbineMake) {
        this.turbineMake = turbineMake;
    }

    public String getTurbineType() {
        return turbineType;
    }

    public void setTurbineType(String turbineType) {
        this.turbineType = turbineType;
    }

    public int getRatedCapacity() {
        return ratedCapacity;
    }

    public void setRatedCapacity(int ratedCapacity) {
        this.ratedCapacity = ratedCapacity;
    }

    public int getHubHeight() {
        return hubHeight;
    }

    public void setHubHeight(int hubHeight) {
        this.hubHeight = hubHeight;
    }

    public int getRotorDia() {
        return rotorDia;
    }

    public void setRotorDia(int rotorDia) {
        this.rotorDia = rotorDia;
    }

    public String getCustomerContactName() {
        return customerContactName;
    }

    public void setCustomerContactName(String customerContactName) {
        this.customerContactName = customerContactName;
    }

    public String getCustomeContactMobileNumber() {
        return customeContactMobileNumber;
    }

    public void setCustomeContactMobileNumber(String customeContactMobileNumber) {
        this.customeContactMobileNumber = customeContactMobileNumber;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}
