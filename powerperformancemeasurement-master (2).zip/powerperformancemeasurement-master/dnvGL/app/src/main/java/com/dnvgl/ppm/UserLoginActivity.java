package com.dnvgl.ppm;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

import com.dnvgl.ppm.database.UserModel;
import com.dnvgl.ppm.viewmodel.UserViewModel;

public class UserLoginActivity extends AppCompatActivity {

    private static final String TAG = "UserLoginActivity";
    private Button loginBtn;
    private EditText userNameEdt;
    private EditText userPassword;

    @Override
    public void onCreate(Bundle onSavedInstanceState) {
        super.onCreate(onSavedInstanceState);

        setContentView(R.layout.activity_userlogin);

        userNameEdt = (EditText) findViewById(R.id.userNameEdt);
        userPassword = (EditText) findViewById(R.id.userpasswdEdt);
        Log.i(TAG, userNameEdt.getText().toString());

        loginBtn = (Button) findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, " Login button OnClick ");
                UserViewModel userViewModel = ViewModelProviders.of(UserLoginActivity.this).get(UserViewModel.class);
                UserModel userModelFromUI = new UserModel();
                userModelFromUI.userName = userNameEdt.getText().toString();
                userModelFromUI.password = userPassword.getText().toString();
                userViewModel.getPasswordByUserName(userModelFromUI);

              /*  if(checkPassword()) {
                    Intent mainIntent = new Intent(UserLoginActivity.this, MainActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("UserName", userNameEdt.getText().toString());
                    mainIntent.putExtras(bundle);
                    startActivity(mainIntent);
                } else {
                    Toast.makeText(UserLoginActivity.this, "Wrong userName or Password", Toast.LENGTH_LONG).show();
                }*/
            }
        });

        Button createUser = (Button) findViewById(R.id.createUserBtn);
        createUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createUserint = new Intent(UserLoginActivity.this, CreateUserActivity.class);
                startActivity(createUserint);
            }
        });
    }


}
