package com.dnvgl.ppm;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

import com.dnvgl.ppm.database.UserModel;
import com.dnvgl.ppm.viewmodel.UserViewModel;

public class CreateUserActivity extends AppCompatActivity {


    private EditText userNameEdt;
    private EditText passwordEdt;
    private UserViewModel userViewModel;

    @Override
    public void onCreate(Bundle onSavedInstanceState) {
        super.onCreate(onSavedInstanceState);

        setContentView(R.layout.activity_createuser);


        userNameEdt = (EditText) findViewById(R.id.userNameEdt);


        passwordEdt = (EditText) findViewById(R.id.userpasswdEdt);

        //Get User View Model
        userViewModel = ViewModelProviders.of(this).get(UserViewModel.class);

        Button createUser = (Button) findViewById(R.id.createUserBtn);
        createUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("CreateUserActivity", "createUser Clicked");
                UserModel userModel = new UserModel();
                userModel.password = passwordEdt.getText().toString();
                userModel.userName = userNameEdt.getText().toString();
                Log.i("CreateUserActivity", "Inserted Before");
                userViewModel.insertAUSer(userModel);
                Log.i("CreateUserActivity", "Inserted");
            }
        });
    }
}
